import React from 'react';
//import logo from './logo.svg';
//import './App.css';
import Layout from './containers/Layout/Layout';

function App() {
  return (
    <div>
      <Layout />
    </div>
  );
}

export default App;
