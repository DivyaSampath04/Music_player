import React from 'react';
import './Actions.css';

const actions = (props) => {
    return(
        <div>
            <div >
                <button className = "But"onClick = {props.clicked}>ALL SONGS</button>
                <button className = "But" onClick = {props.createClicked}>CREATE PLAYLIST</button>
                <button className = "But" onClick = {props.playClicked}>PLAYLIST</button>
                
            </div>
            <div>
                    <input className = "Search" type = "text" placeholder = "Search for a song" onChange = {props.changed}/>
                </div>
        </div>
    );
}

export default actions;