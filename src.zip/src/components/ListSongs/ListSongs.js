import React , {Component} from 'react';
import './ListSongs.css';

    class ListSongs extends Component {
       

   
    render(){
       // console.log(this.props.searchValue);
       // console.log(this.props.title);
        return(
            <div className = "ListSongs">
                {this.props.list === true ?
                <div>
               {this.props.search === true ?
               <div>
                   {this.props.title.indexOf(this.props.searchValue) !== -1 ?
                   <div >
                    
                       <div> Song Name : {this.props.title} </div>
                       <div style = {{fontStyle : "italic"}}> Author : {this.props.author} </div>
                    </div> : null }
                </div> :
                       <div >
                       <div> Song name :  {this.props.title} </div>
                        <div style = {{fontStyle : "italic"}}> Author : {this.props.author} </div>
                        </div>
                
                    }  </div>
                    : <div >
                    <div> Song name :  {this.props.title} </div>
                     <div style = {{fontStyle : "italic"}}> Author : {this.props.author} </div>
                     </div>}  
            </div>
        
        );
    }
}

export default ListSongs;