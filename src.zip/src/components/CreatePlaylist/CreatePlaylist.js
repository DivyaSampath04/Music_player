import React , {Component} from 'react';
import './CreatePlaylist.css';

class CreatePlaylist extends Component {
  

    render () {
        return (
            
            <div className = "CreatePlaylist">
                <h1>Add a Song</h1>
                <label>Title</label>
                <input type="text" value={this.props.title} onChange={this.props.createPlayTitleHandler} />
                <label>Author</label>
                <select value={this.props.author} onChange={this.props.createPlayHandler}>
                    <option value="Justin">Justin</option>
                    <option value="Michael">Michael</option>
                </select>
                <button onClick = {this.props.addPostHandler}>Add to playlist</button>
                
        
            </div>
            
        );
    }
}

export default CreatePlaylist;