import React from 'react';
import './PlayList.css';

const playList = (props) => {
    return(
        <div className = "PlayList">
            
            <div className = "PlayList">
           <div style = {{fontStyle : "italic"}}> Song Title : {props.title}</div>
            <div style = {{fontStyle : "italic"}}>Author name : {props.author}</div>
            </div>
            </div>
    )
}

export default playList;