import React , {Component} from 'react';
import axios from 'axios';
import Actions from '../../components/Actions/Actions';
import ListSongs from '../../components/ListSongs/ListSongs';
import CreatePlaylist from '../../components/CreatePlaylist/CreatePlaylist';
import PlayList from '../../components/PlayList/PlayList';


class Layout extends Component {
    state = {
        songs : [],
        toList : false,
        selectedPost : null,
        error : '',
        songName : null,
        search : false,
        create : false,
        play : false,
        title: '',
        author: 'Justin'
        
    }
    
    addPostHandler = () =>{
        const data = {
            title : this.state.title,
           // body : this.state.content,
            author : this.state.author
        
        }
        axios.post('https://jsonplaceholder.typicode.com/posts', data)
        .then(response => {
            console.log(response);
        });
    }

    componentDidMount () {
        axios.get("https://jsonplaceholder.typicode.com/posts")
        .then(response => {
            //console.log(response.data);
            const song = response.data.slice(0,10);
            const updatedsong = song.map(sng => {
                return {
                    ...sng,
                    author : 'Justin'
                }
            });
           this.setState({songs : updatedsong});
        }).catch(error => {
            //console.log(error);
            this.setState({error : true});
        });
    }
    listAllSongs = () =>{
       // console.log(this.state.toList);
        this.setState({toList : true});
        this.setState({play : false});
        this.setState({create : false});
    }
    changeHandler = (event) => {
        this.setState({search : true});
        this.setState({songName : event.target.value})
       // console.log(this.state.songName);

    }
    createHandler = () => {
        this.setState({create : true});
        this.setState({play : false});
        this.setState({toList : false});
    }
    playHandler = () => {
        this.setState({play : true});
        this.setState({create : false});
        this.setState({toList : false});
    }
    createPlayHandler = (event) => {
        
        this.setState({author : event.target.value});
    }
    createPlayTitleHandler = (event) => {
        this.setState({title : event.target.value});
    }
    render() {
        let songs = "";
        if(!this.state.error && this.state.toList === true && this.state.create === false){
        songs = this.state.songs.map(song => {
            return <ListSongs 
            key = {song.id} 
            title = {song.title} 
            author = {song.author}
            search = {this.state.search}
            searchValue = {this.state.songName}
            create = {this.state.create}
            list = {this.state.toList}
            />
        });
    }   
        return(
            <div>
               <Actions 
               clicked = {this.listAllSongs} 
               changed = {this.changeHandler} 
               createClicked = {this.createHandler}
               playClicked = {this.playHandler}/>


               {songs}

               {this.state.create === true  ?
               <CreatePlaylist 
               play = {this.state.play}
               addPostHandler = {this.addPostHandler}
               title = {this.state.title}
               author = {this.state.author}
               createPlayHandler = {this.createPlayHandler}
               createPlayTitleHandler = {this.createPlayTitleHandler}
              
               /> : null}

                {this.state.play === true ?
               <PlayList 
               title = {this.state.title}
               author = {this.state.author}
               /> : null}
               
        
            </div>
        )
    }
}

export default Layout;

